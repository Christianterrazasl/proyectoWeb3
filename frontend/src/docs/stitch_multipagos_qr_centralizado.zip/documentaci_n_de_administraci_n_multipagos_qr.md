# Documentación del Módulo de Administración: Multipagos QR

## 1. Propósito
La Consola de Administración Global es el centro de control estratégico de la plataforma. Permite a los super-administradores monitorear la salud financiera del sistema, gestionar el ecosistema de proveedores y responder a incidencias en tiempo real.

## 2. Componentes del Tablero
### A. Panel de Métricas (KPIs)
*   **Volumen Total Procesado:** Sumatoria histórica de transacciones aprobadas.
*   **Proveedores Activos:** Conteo de empresas validadas vs. las que están en proceso de revisión.
*   **Tasa de Aprobación:** Porcentaje de éxito de los pagos QR generados.

### B. Visualización de Datos
*   **Gráfico de Rendimiento:** Histograma de volumen transaccional de los últimos 7 días para identificar picos de uso.

### C. Gestión de Tenencia (Multi-tenant)
*   **Directorio de Empresas:** Vista tabular que muestra el ID fiscal, sector y estado de afiliación. Permite la aprobación manual de nuevos proveedores.

### D. Live Feed (Monitoreo en Tiempo Real)
*   Bitácora de eventos críticos:
    *   `Scan exitoso`: Confirmación de pago.
    *   `Nuevo Registro`: Alerta de empresa solicitando unirse.
    *   `Falla de Sistema`: Errores técnicos o de fondos.

## 3. Especificaciones de Diseño
*   **Cards de Datos:** Uso de `Surface Container` con bordes sutiles para separar métricas.
*   **Estados de Color:** 
    *   `Aprobado`: Cyan Neon / Verde Esmeralda.
    *   `Pendiente`: Ámbar/Naranja.
    *   `Error`: Rojo Carmesí.
*   **Interacciones:** Cada fila de empresa es accionable para entrar al detalle del tenant.

---
*Documento actualizado para incluir el rol Administrador.*