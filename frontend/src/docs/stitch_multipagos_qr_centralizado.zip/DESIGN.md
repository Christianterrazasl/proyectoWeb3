---
name: Lumina Direct
colors:
  surface: '#101415'
  surface-dim: '#101415'
  surface-bright: '#363a3b'
  surface-container-lowest: '#0b0f10'
  surface-container-low: '#191c1e'
  surface-container: '#1d2022'
  surface-container-high: '#272a2c'
  surface-container-highest: '#323537'
  on-surface: '#e0e3e5'
  on-surface-variant: '#c6c6cd'
  inverse-surface: '#e0e3e5'
  inverse-on-surface: '#2d3133'
  outline: '#909097'
  outline-variant: '#45464d'
  surface-tint: '#bec6e0'
  primary: '#bec6e0'
  on-primary: '#283044'
  primary-container: '#0f172a'
  on-primary-container: '#798098'
  inverse-primary: '#565e74'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#2fd9f4'
  on-tertiary: '#00363e'
  tertiary-container: '#001b20'
  on-tertiary-container: '#008ea1'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#a2eeff'
  tertiary-fixed-dim: '#2fd9f4'
  on-tertiary-fixed: '#001f25'
  on-tertiary-fixed-variant: '#004e5a'
  background: '#101415'
  on-background: '#e0e3e5'
  surface-variant: '#323537'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  code-numeric:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is engineered for a high-velocity QR payment ecosystem. The brand personality balances the stoic reliability of traditional finance with the kinetic energy of modern fintech. It targets a demographic that values efficiency, security, and a frictionless "scan-and-go" experience.

The visual style is **Tech-Forward Minimalism**. It utilizes heavy whitespace to reduce cognitive load during financial transactions, punctuated by vibrant neon accents that guide the eye to primary actions. The interface employs a sophisticated layering strategy—mixing deep, solid foundations with translucent, glassmorphic overlays to create a sense of digital depth and "intelligent" surfaces.

## Colors
This design system utilizes a "Deep-Sea" palette to maximize contrast and focus.

*   **Primary (#0F172A):** The "Midnight" base. Used for all background surfaces and structural elements to provide a stable, high-contrast environment for data.
*   **Secondary (#6366F1):** "Electric Indigo." Used for secondary actions, active states, and brand-building visual flourishes.
*   **Tertiary/Accent (#22D3EE):** "Neon Cyan." Reserved strictly for high-priority CTAs, successful payment states, and the scanning reticle. It must contrast sharply against the Midnight base.
*   **Neutral (#F8FAFC):** "Ghost White." Used primarily for typography and icons to ensure AAA accessibility ratings on dark backgrounds.

## Typography
Inter is the sole typeface for this design system to ensure maximum legibility across variable screen qualities. 

For payment flows, use **Display LG** for the transaction amount to create an immediate focal point. **Label-bold** should be used in all-caps for metadata headers in tables (e.g., "TRANSACTION ID"). The **Code-numeric** style is specifically optimized for displaying PIN entries or QR-encoded strings, featuring increased letter-spacing to prevent character crowding.

## Layout & Spacing
The design system follows an **8px soft-grid** system. 

*   **Mobile:** 4-column fluid grid. The QR scanner occupies the central square of the upper viewport. 16px horizontal margins.
*   **Desktop:** 12-column fixed grid centered at 1200px. Dashboards use a sidebar-navigation model (280px width) with a fluid content area for data tables.
*   **Spacing Rhythm:** Use `stack-lg` to separate distinct sections (e.g., between the QR code and the payment details). Use `stack-sm` for internal component spacing (e.g., label to input field).

## Elevation & Depth
Depth is created through **Glassmorphism and Tonal Layering** rather than traditional heavy shadows.

1.  **Level 0 (Base):** #0F172A (The background).
2.  **Level 1 (Cards/Tables):** A slightly lighter tint of the primary color with a 1px #FFFFFF10 border.
3.  **Level 2 (Overlays/Modals):** Glassmorphic surfaces using a background blur (20px) and a semi-transparent fill (#FFFFFF05). 
4.  **Shadows:** Use a single, extra-diffused "Ambient Indigo" shadow for active elements: `0px 20px 40px -12px rgba(99, 102, 241, 0.25)`.

## Shapes
The shape language is friendly but structured. A standard `rounded-md` (0.5rem) is used for inputs and small buttons. However, primary containers, glass cards, and large CTAs should utilize `rounded-xl` (1.5rem) to evoke a modern, premium feel. 

The QR code container itself should feature a unique treatment: a white solid background with a slightly rounded inner-clip to soften the aesthetic of the technical code.

## Components
*   **Buttons:** Primary buttons use a solid Neon Cyan (#22D3EE) fill with black text for maximum "pop." Secondary buttons use the Indigo border with no fill.
*   **QR Scanner:** A dedicated component featuring a central "active zone" with Neon Cyan corner brackets that pulse subtly.
*   **Data Tables:** Rows should be separated by a subtle 1px divider (#FFFFFF08). The "Status" column uses high-contrast chips (e.g., Success = Neon Cyan text on a low-opacity cyan background).
*   **Glass Cards:** Used for user balance and card details. These must include the 20px backdrop blur and a diagonal linear gradient border to simulate a "glass edge."
*   **Input Fields:** Deep midnight fill, 1px Indigo border on focus. Labels sit strictly above the input, never as placeholders.